import React, { useEffect } from 'react';

export default function Reviews({ r }) {
  useEffect(() => {}, []);
  return <div>{console.log(r)}</div>;
}

import React from 'react';

function PaginationItem() {
  return <div>PaginationItem</div>;
}

export default PaginationItem;

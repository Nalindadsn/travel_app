import React from 'react';
import Layout from '../components/Layout';

function about() {
  return <Layout>about</Layout>;
}

export default about;

import React from 'react';
import Layout from '../components/Layout';

function contact() {
  return <Layout>contact</Layout>;
}

export default contact;
